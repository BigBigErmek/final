from django.contrib import admin
from .models import Houses, Testimony, News, Agent

admin.site.register(Houses)
admin.site.register(Testimony)
admin.site.register(News)
admin.site.register(Agent)