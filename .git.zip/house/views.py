from django.shortcuts import render
from .models import Houses, News, Testimony, Agent

def main(request):
    first_three_houses = Houses.objects.filter(main=True)
    houses = Houses.objects.filter(main=False)
    news = News.objects.all()
    testimony = Testimony.objects.all()
    agents = Agent.objects.all()
    content = {
        'first_three_houses':first_three_houses,
        'houses':houses,
        'news':news,
        'testimony':testimony,
        'agents':agents
    }
    return render(request, 'index.html', content)
