from django.db import models


class Houses(models.Model):
    photo = models.ImageField(upload_to='media/')
    state = models.CharField(max_length=250)
    rent_cost = models.IntegerField()
    house_number = models.IntegerField()
    address_1 = models.CharField(max_length=250)
    address_2 = models.CharField(max_length=250)
    postal_code = models.IntegerField()
    area = models.IntegerField()
    beds = models.IntegerField()
    baths = models.IntegerField()
    garages = models.IntegerField()
    main = models.BooleanField()


class Agent(models.Model):
    photo = models.ImageField(upload_to='media/')
    name = models.CharField(max_length=250)
    description = models.TextField()
    phone = models.CharField(max_length=250)
    email = models.CharField(max_length=250)
    instagram = models.CharField(max_length=250)
    facebook = models.CharField(max_length=250)
    twitter = models.CharField(max_length=250)
    linkedin = models.CharField(max_length=250)

class News(models.Model):
    tag = models.CharField(max_length=10)
    photo = models.ImageField(upload_to='media/')
    title = models.CharField(max_length=250)
    date = models.DateField()

class Testimony(models.Model):
    photo = models.ImageField(upload_to='media/')
    mini_photo = models.ImageField(upload_to='media/')
    name = models.CharField(max_length=250)
    content = models.TextField()